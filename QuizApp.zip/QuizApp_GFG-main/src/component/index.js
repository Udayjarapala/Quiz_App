export { Navbar } from "./Navbar/Navbar";
export { QuizCard } from "./QuizCard/QuizCard";
export { AuthLogin } from "./Auth/Login";
export { QuestionAndOptions } from "./QuestionAndOptions/QNA";