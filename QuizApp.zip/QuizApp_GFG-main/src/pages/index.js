export { Home } from "./Home/Home";
export { Login } from "./Login/Login";
export { Quiz } from "./Quiz/Quiz";
export { Result } from "./Result/Result";